<?php
require("../inc/control.php");
header("Location: " . $BASE_HREF);
?>